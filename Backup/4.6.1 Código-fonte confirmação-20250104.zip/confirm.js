var sair = confirm("Confirma ir para a página do Google?");
if(sair == 1){
  window.location = "http://www.google.com.br";
}