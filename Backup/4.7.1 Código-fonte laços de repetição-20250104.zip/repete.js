var repete = 1;
while(repete <= 5){
	alert("Mensagem: " + repete);
	repete = repete + 1;
}